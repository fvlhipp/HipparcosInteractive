<h3 id="outputformat"> Output format </h3>
[fig51]: Images/CaptureOutputFormat.png "Fig.51, Output formats"
[1]: ../OutputOptions.md

![OutputFormat][fig51]

Four output formats are specified, all of which produce fixed-format records:

- Separation by single space
- Separation by comma, as in CSV file
- Separation by tab
- Separation as in LaTeX tabular
 
[Back][1]