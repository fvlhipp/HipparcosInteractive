<h3 id="outputident"> Identifiers </h3>
[fig47]: Images/CaptureOutputIdent.png "Identifiers"
[1]: ../OutputOptions.md

![Identifiers][fig47]

To add one or more identifiers to the output records, simply tick the check boxes of the identifiers required. There is either a single- or three-character space between two identifiers, depending on the output format, either plain text or with LaTeX-table or other markings. 

[Back][1]
