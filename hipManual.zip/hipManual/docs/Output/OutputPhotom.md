<h3 id="outputphotom"> Photometry output </h3>
[fig50]: Images/CaptureOutputPhotom.png "Fig.50, Photometry"
[1]: ../OutputOptions.md

![Photometry][fig50]

The Photometry tab shows the output fields available for fluxes, colours and variability. The absolute magnitudes and their standard errors are obtained from the observed magnitudes, the parallax and the error on the parallax. The error on the observed magnitude is generally much smaller.

[Back][1]
