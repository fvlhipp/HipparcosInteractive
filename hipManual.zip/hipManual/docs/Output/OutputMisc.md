<h3 id="misceldata"> Miscellaneous data </h3>
[fig52]: Images/CaptureOutputOther.png "Fig.52, Other outputs"
[1]: ../OutputOptions.md

![Miscellaneous][fig52]

Finally, the last tab provides access to radial velocity, orbital period and binary system (separation, orientation and magnitude difference) data to be output.

[Back][1]