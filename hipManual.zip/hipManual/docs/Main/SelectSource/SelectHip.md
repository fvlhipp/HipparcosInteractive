<h4 id="selectedHip"> Selected Hip tab </h4>

[fig06]: Images/CaptureNotHipStar.png "Fig.6, Not Hipparcos Star"
[fig07]: Images/CaptureSelectedSingle.png "Fig.07, Single star selected"
[fig08]: Images/CaptureSelectedDouble.png "Fig.8, Double star selected"
[2]: ../SelectSource.md
[3]: ../SummaryInfWind.md

Not a Hipparcos star

![Not Hipparcos Star][fig06]

A single star selected

![Single star selected][fig07]

When a catalogue entry is associated with a double or multiple system for which more than one component has an individual catalogue entry, all components are shown as selected.

A double star with two entries selected

![Double star selected][fig08]

The Show data button activates the [Summary Information][3] window.

[Back][2]
