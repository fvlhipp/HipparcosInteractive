<h4 id=gyrotransf> Gyroscope projection corrections </h4>

[1]: ../CalibrationMisc.md
[2]: Images/CaptureGyroOrient.png "Gyro orientation corrections"

![Gyro orientation corrections][2]

The gyroscope orientation calibrations describe the corrections to the assumed input axis orientations as these evolved over the mission.

[Back][1]