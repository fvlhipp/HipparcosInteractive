<h3 id="selectsource"> Single stars tab </h3>
[1]: SelectSource/SelectByNumber.md
[2]: SelectSource/SelectSolution.md
[3]: SelectSource/SelectPosition.md
[4]: SelectSource/SelectHip.md
[5]: ../MainWindow.md
[fig01]: Images/CaptureSelectNumber.png "Select souce Panel"

![Select source][fig01]

Single or multiple entries in the Hipparcos catalogue can be selected using one of three different criteria:

- [by number][1]
- [by solution type][2]
- [by position][3] 

In each case the Hipparcos number for the selected sours or sources will appear in the [top window][4]

[Back][5]