## Development Tools ##
[7]: http://www.jfree.org/jfreechart/
[8]: http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html
[9]: https://netbeans.org/downloads/
[10]: http://www.java2s.com/Code/Java/Swing-Components/CatalogSwing-Components.htm
[11]: https://en.wikipedia.org/wiki/JAR_%28file_format%29

The coding is in [Java JDK 8] [8], using [NetBeans 8.1] [9] as IDE, making extensive use of [Java Swing components] [10] for building graphical user interfaces. The graphics tool used for creating charts is [jFreeChart] [7]. The software is released as stand-alone [Java jar] [11] file, but requires [Java JDK 8] [8] to be installed.
