<h3 id="pdfchart"> Pdf copies of charts </h3>
[fig40]: Images/CapturePdfChartFile.png "Fig.40, Chart pdf file"
![Chart pdf file][fig40]

When pushing the **Pdf copy chart** button on any of the windows showing charts (and only when a tab with chart is selected), the above dialogue box appears. Here the user can specify the paper size and orientation, and either accepts the default folder and file name, or set these as required (**Set file name** button). By pushing the Accept button, the **Apply & Close** button appears, pushing which completes the task and creates the pdf file for the chart. 
